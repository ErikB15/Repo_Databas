package controller;

/**
* kolla igenom databas, lör dig den opch ta bport kommentarer
 */

public class Main {
    public static void main(String[] args) throws Exception {
        Controller controller = new Controller();
        controller.start();
    }
}

